const config = {}

config.alexa = {
	id: 	"amzn1.ask.skill.e1c3ca0f-04cd-4598-a93f-df0a1ab8add5"
}

config.firebase = {}

config.firebase.default = {
	apiKey				: "AIzaSyBqbgRVPkr7-t71RqpM47V6HEC3rsq83G8",
	authDomain			: "smartdesk-5705d.firebaseapp.com",
	databaseURL			: "https://smartdesk-5705d.firebaseio.com",
	projectId			: "smartdesk-5705d",
	storageBucket		: "smartdesk-5705d.appspot.com",
	messagingSenderId	: "166438428269"
};

config.firebase.service = {
    databaseURL			: 'https://smartdesk-5705d.firebaseio.com',
    serviceAccount		: './smartdesk-service.json'
};

module.exports = config